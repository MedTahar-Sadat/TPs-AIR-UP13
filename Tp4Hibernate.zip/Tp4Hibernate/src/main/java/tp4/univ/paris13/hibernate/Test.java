package tp4.univ.paris13.hibernate;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


import tp4.univ.paris13.hibernate.HibernateUtil;
import tp4.univ.paris13.model.Personne;
import tp4.univ.paris13.model.adresse;
public class Test {
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		Session session = null;
		
				try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory(); 
			session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction(); // Commencez une unité d'oeuvre et renvoyez l'objet Transaction associé
			
			List<Personne>personnes = session.createCriteria(Personne.class).list(); //Créez une nouvelle instance de critères pour personne
			System.out.println("With CRITERIA API : personnes : "+personnes.toString());//afficher les paramétres d'un objet dans DB

			List<Personne>personnesHQL = session.createQuery("FROM Personne").list(); 
			System.out.println("WITH HQL QUERY : personnesHQL : "+personnesHQL.size()); // création d'une 
			
			List<Personne>personnesSQL = session.createSQLQuery("select * from personne").list(); //Créez une nouvelle instance de SQLQuery en requête SQL
			System.out.println("WITH SQL QUERY : personnesSQL : "+personnesSQL.size()) ;
			
			List<adresse>adresse = session.createCriteria(adresse.class).list(); //Créez une nouvelle instance de critères pour personne
			System.out.println("With CRITERIA API : adresse : "+adresse.toString());//afficher les valeurs de personne 

			List<adresse>adressesHQL = session.createQuery("FROM adresse").list(); 
			System.out.println("WITH HQL QUERY : adresseHQL : "+adressesHQL.size());
			
			List<adresse>adressesSQL = session.createSQLQuery("select * from adresse").list(); //Créez une nouvelle instance de SQLQuery en requête SQL
			System.out.println("WITH SQL QUERY : personnesSQL : "+adressesSQL.size()) ;
			
			
			tx.commit();
			System.out.println("Done");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.flush();
			session.close();
		}	}}
