package tp4.univ.paris13.model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "adresse")
public class adresse {

@Id @GeneratedValue
@Column(name="id")
private Integer id;
@Column(name="numero")
private Integer numero;
@Column(name="rue")
private String rue;
@Column(name="code postal")
private String codePostal;
@Column(name="ville")
private String ville;
@Column(name="pays")
private String pays;
private Set<Personne> personnes;


public adresse() {
super();
// TODO Auto-generated constructor stub
}





@Override
public String toString() {
	return "adresse [id=" + id + ", numero=" + numero + ", rue=" + rue + ", codePostal=" + codePostal + ", ville="
			+ ville + ", pays=" + pays + ", personnes=" + personnes + "]";
}





public Integer getId() {
return id;
}
public void setId(Integer id) {
this.id = id;
}
public Integer getNumero() {
return numero;
}
public void setNumero(Integer numero) {
this.numero = numero;
}
public String getRue() {
return rue;
}
public void setRue(String rue) {
this.rue = rue;
}
public String getCodePostal() {
return codePostal;
}
public void setCodePostal(String codePostal) {
this.codePostal = codePostal;
}
public String getVille() {
return ville;
}
public void setVille(String ville) {
this.ville = ville;
}
public String getPays() {
return pays;
}
public void setPays(String pays) {
this.pays = pays;
}

public Set<Personne> getPersonnes() {
return personnes;
}

public void setPersonnes(Set<Personne> personnes) {
this.personnes = personnes;
}
}

